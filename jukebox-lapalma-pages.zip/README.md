
# Jukebox La Palma 🎶🍻

App web para que los clientes de tu licorera escojan la música desde su celular escaneando un QR.

## ¿Cómo desplegar?

1. Crea una cuenta en https://github.com y sube este proyecto.
2. Conecta tu cuenta de GitHub con https://vercel.com.
3. Vercel detectará este proyecto y lo desplegará automáticamente.
4. Copia el enlace del sitio publicado y crea un QR con él.

¡Listo para usar en tu negocio!
